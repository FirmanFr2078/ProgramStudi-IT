"use client"

import { useState } from "react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "cn"
import type { DialogState, PosisiFormValues } from "@/hooks/dashboard/struktur/use-struktur-board"
import { canBeLurus, idsRemoved, planDelete, type DeleteMode, type Jalur } from "@/lib/struktur-tree"
import type { DosenAdmin, StrukturPosisiAdmin } from "@/types"

type FormValues = { sumber: "dosen" | "custom"; dosenId: string | null; nama: string; jabatan: string; jalur: Jalur }

const JALUR_LABEL: Record<Jalur, string> = {
  lurus: "Lurus (di garis utama)",
  kiri: "Kiri (di sisi kiri garis)",
  kanan: "Kanan (di sisi kanan garis)",
}

const JALUR_HINT: Record<Jalur, string> = {
  lurus: "Tepat di bawah atasannya, di garis utama. Hanya satu per baris, dan hanya di baris terakhir.",
  kiri: "Di sisi kiri garis utama, selevel dengan kartu lain di baris yang sama.",
  kanan: "Di sisi kanan garis utama, selevel dengan kartu lain di baris yang sama.",
}

function toFormValues(posisi: StrukturPosisiAdmin | undefined): FormValues {
  if (!posisi) return { sumber: "custom", dosenId: null, nama: "", jabatan: "", jalur: "lurus" }
  return {
    sumber: posisi.dosenId ? "dosen" : "custom",
    dosenId: posisi.dosenId,
    nama: posisi.nama ?? "",
    jabatan: posisi.jabatan,
    jalur: posisi.jalur,
  }
}

function dialogTitle(dialog: DialogState, editing: StrukturPosisiAdmin | undefined): string {
  if (dialog.mode === "edit") return `Ubah posisi${editing ? ` — ${editing.jabatan}` : ""}`
  if (dialog.mode !== "create") return ""
  switch (dialog.target.kind) {
    case "child":
      return "Tambah bawahan"
    case "side":
      return dialog.target.side === "kiri" ? "Tambah posisi setara (kiri)" : "Tambah posisi setara (kanan)"
    case "spine":
      return "Sisipkan posisi di garis"
    case "above":
      return "Tambah atasan"
  }
}

// ============================================================
// HAPUS
// ============================================================

function DeleteChoice({
  editing,
  posisi,
  onConfirm,
  onCancel,
}: {
  editing: StrukturPosisiAdmin
  posisi: StrukturPosisiAdmin[]
  onConfirm: (mode: DeleteMode) => void
  onCancel: () => void
}) {
  const plan = planDelete(posisi, editing.id)
  const [mode, setMode] = useState<DeleteMode>("cascade")

  const needsChoice = plan.otherChildIds.length > 0
  const cascadeCount = Math.max(0, idsRemoved(posisi, editing.id, "cascade").length - 1)

  if (!needsChoice) {
    return (
      <>
        <DialogHeader>
          <DialogTitle>Hapus &quot;{editing.jabatan}&quot;?</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          {plan.pathChildId
            ? "Posisi di bawahnya (jalur menuju Ketua Program Studi) otomatis tersambung ke atasannya."
            : "Posisi ini tidak punya bawahan."}
        </p>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            Batal
          </Button>
          <Button type="button" variant="destructive" onClick={() => onConfirm("cascade")}>
            Hapus
          </Button>
        </DialogFooter>
      </>
    )
  }

  const options: { value: DeleteMode; title: string; description: string; disabled: boolean }[] = [
    {
      value: "cascade",
      title: "Hapus beserta turunannya",
      description:
        cascadeCount > 0
          ? `${cascadeCount} posisi di bawahnya ikut terhapus.`
          : "Hanya posisi ini yang terhapus.",
      disabled: false,
    },
    {
      value: "promote",
      title: "Naikkan turunannya",
      description: plan.canPromote
        ? "Bawahan langsungnya menggantikan tempat posisi ini."
        : "Tidak bisa: posisi ini paling atas dan tidak ada atasan untuk menampung bawahannya.",
      disabled: !plan.canPromote,
    },
  ]

  return (
    <>
      <DialogHeader>
        <DialogTitle>Hapus &quot;{editing.jabatan}&quot;?</DialogTitle>
      </DialogHeader>

      {plan.pathChildId && (
        <p className="text-sm text-muted-foreground">
          Jalur menuju Ketua Program Studi selalu dipertahankan dan tersambung otomatis.
        </p>
      )}

      <div className="space-y-2">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            disabled={option.disabled}
            onClick={() => setMode(option.value)}
            className={cn(
              "w-full rounded-lg border px-3 py-2.5 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-50",
              mode === option.value ? "border-primary bg-primary/5" : "border-border hover:border-primary/40",
            )}
          >
            <p className="text-sm font-medium">{option.title}</p>
            <p className="text-xs text-muted-foreground">{option.description}</p>
          </button>
        ))}
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Batal
        </Button>
        <Button type="button" variant="destructive" onClick={() => onConfirm(mode)}>
          Hapus
        </Button>
      </DialogFooter>
    </>
  )
}

// ============================================================
// KARTU KAPRODI (hanya info -- datanya diambil dari modul Dosen)
// ============================================================

function KaprodiInfo({ editing, onClose }: { editing: StrukturPosisiAdmin; onClose: () => void }) {
  return (
    <>
      <DialogHeader>
        <DialogTitle>Ketua Program Studi</DialogTitle>
      </DialogHeader>

      <div className="space-y-3 text-sm">
        <p className="text-muted-foreground">
          Kartu ini diambil otomatis dari dosen yang jabatan strukturalnya &quot;Ketua Program Studi&quot;, jadi tidak
          diubah dari sini.
        </p>

        {editing.kaprodiInvalid === "kosong" && (
          <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-destructive">
            Belum ada dosen yang ditandai sebagai Ketua Program Studi.
          </p>
        )}
        {editing.kaprodiInvalid === "ganda" && (
          <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-destructive">
            Ada lebih dari satu dosen yang ditandai sebagai Ketua Program Studi. Sisakan satu saja.
          </p>
        )}
        {!editing.kaprodiInvalid && editing.dosenNama && (
          <p>
            <span className="font-medium">{editing.dosenNama}</span>
            {editing.dosenNidn && <span className="text-muted-foreground"> · NIDN: {editing.dosenNidn}</span>}
          </p>
        )}

        <Link href="/dashboard/sdm/dosen" className="inline-block text-primary underline underline-offset-4">
          Buka menu Dosen
        </Link>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>
          Tutup
        </Button>
      </DialogFooter>
    </>
  )
}

// ============================================================
// FORM
// ============================================================

function PosisiForm({
  dialog,
  editing,
  posisi,
  dosenOptions,
  onSubmit,
  onDelete,
  onClose,
}: {
  dialog: DialogState
  editing: StrukturPosisiAdmin | undefined
  posisi: StrukturPosisiAdmin[]
  dosenOptions: DosenAdmin[]
  onSubmit: (values: PosisiFormValues) => void
  onDelete: (id: string, mode: DeleteMode) => void
  onClose: () => void
}) {
  const [values, setValues] = useState<FormValues>(() => toFormValues(editing))
  const [confirmingDelete, setConfirmingDelete] = useState(false)

  if (editing?.isKaprodi) {
    return <KaprodiInfo editing={editing} onClose={onClose} />
  }

  if (confirmingDelete && editing) {
    return (
      <DeleteChoice
        editing={editing}
        posisi={posisi}
        onConfirm={(mode) => onDelete(editing.id, mode)}
        onCancel={() => setConfirmingDelete(false)}
      />
    )
  }

  // Jalur hanya ditanyakan kalau memang ada pilihan: bawahan pertama, sisip di garis, atau ubah posisi.
  const showJalur =
    (dialog.mode === "create" && (dialog.target.kind === "child" || dialog.target.kind === "spine")) ||
    (dialog.mode === "edit" && !!editing && editing.parentId !== null)

  const lurusAllowed = dialog.mode === "edit" && editing ? editing.jalur === "lurus" || canBeLurus(posisi, editing.id) : true

  function handleSubmit() {
    onSubmit({
      jabatan: values.jabatan.trim(),
      dosenId: values.sumber === "dosen" ? values.dosenId : null,
      nama: values.sumber === "custom" ? values.nama.trim() || null : null,
      jalur: values.jalur,
    })
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>{dialogTitle(dialog, editing)}</DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        <div className="space-y-1.5">
          <Label>Sumber</Label>
          <Select
            value={values.sumber}
            onValueChange={(value) => value && setValues((prev) => ({ ...prev, sumber: value as "dosen" | "custom" }))}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dosen">Ambil dari data dosen</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {values.sumber === "dosen" ? (
          <div className="space-y-1.5">
            <Label>Dosen</Label>
            <Select
              value={values.dosenId ?? ""}
              onValueChange={(value) => value && setValues((prev) => ({ ...prev, dosenId: value }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Pilih dosen" />
              </SelectTrigger>
              <SelectContent>
                {dosenOptions.map((dosen) => (
                  <SelectItem key={dosen.id} value={dosen.id}>
                    {dosen.nama} — {dosen.nidn}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : (
          <div className="space-y-1.5">
            <Label htmlFor="posisi-nama">Nama (opsional)</Label>
            <Input
              id="posisi-nama"
              value={values.nama}
              onChange={(event) => setValues((prev) => ({ ...prev, nama: event.target.value }))}
              placeholder="Kosongkan kalau belum ada orangnya"
            />
          </div>
        )}

        <div className="space-y-1.5">
          <Label htmlFor="posisi-jabatan">Jabatan</Label>
          <Input
            id="posisi-jabatan"
            value={values.jabatan}
            onChange={(event) => setValues((prev) => ({ ...prev, jabatan: event.target.value }))}
            placeholder='Misal: "Koordinator PKL"'
          />
        </div>

        {showJalur && (
          <div className="space-y-1.5">
            <Label>Jalur</Label>
            <Select
              value={values.jalur}
              onValueChange={(value) => value && setValues((prev) => ({ ...prev, jalur: value as Jalur }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lurus" disabled={!lurusAllowed}>
                  {JALUR_LABEL.lurus}
                </SelectItem>
                <SelectItem value="kiri">{JALUR_LABEL.kiri}</SelectItem>
                <SelectItem value="kanan">{JALUR_LABEL.kanan}</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">{JALUR_HINT[values.jalur]}</p>
            {!lurusAllowed && (
              <p className="text-xs text-muted-foreground">
                &quot;Lurus&quot; tidak tersedia: baris ini sudah punya kartu lurus atau bukan baris terakhir.
              </p>
            )}
          </div>
        )}
      </div>

      <DialogFooter className="justify-between sm:justify-between">
        {dialog.mode === "edit" && editing ? (
          <Button type="button" variant="destructive" onClick={() => setConfirmingDelete(true)}>
            Hapus posisi
          </Button>
        ) : (
          <span />
        )}

        <Button
          type="button"
          disabled={!values.jabatan.trim() || (values.sumber === "dosen" && !values.dosenId)}
          onClick={handleSubmit}
        >
          Simpan
        </Button>
      </DialogFooter>
    </>
  )
}

export function PosisiDialog({
  dialog,
  posisi,
  dosenOptions,
  onClose,
  onSubmit,
  onDelete,
}: {
  dialog: DialogState
  posisi: StrukturPosisiAdmin[]
  dosenOptions: DosenAdmin[]
  onClose: () => void
  onSubmit: (values: PosisiFormValues) => void
  onDelete: (id: string, mode: DeleteMode) => void
}) {
  const editing = dialog.mode === "edit" ? posisi.find((item) => item.id === dialog.posisiId) : undefined
  const isOpen = dialog.mode !== "closed"

  const formKey =
    dialog.mode === "edit"
      ? `edit-${dialog.posisiId}`
      : dialog.mode === "create"
        ? `create-${JSON.stringify(dialog.target)}`
        : "closed"

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        {dialog.mode !== "closed" && (
          <PosisiForm
            key={formKey}
            dialog={dialog}
            editing={editing}
            posisi={posisi}
            dosenOptions={dosenOptions}
            onSubmit={onSubmit}
            onDelete={onDelete}
            onClose={onClose}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}
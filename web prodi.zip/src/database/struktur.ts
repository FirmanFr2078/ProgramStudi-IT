import "server-only"

import type { Prisma } from "@generated/client"

import { logEntityMutation, type Actor } from "@/lib/authorship"
import { parseBigIntId } from "@/lib/ids"
import { prisma } from "@/lib/prisma"
import { getPublicUrl } from "@/lib/storage"
import type {
  JalurSambung,
  StrukturPosisiAdmin,
  StrukturPosisiCreateInput,
  StrukturPosisiUpdateInput,
  StrukturTupoksiAdmin,
  StrukturTupoksiInput,
  StrukturTupoksiUpdateInput,
} from "@/types"
import { STRUKTUR_TUPOKSI_MAX_ITEMS } from "@/types"

const ENTITY = "tbl_struktur_posisi"
const TUPOKSI_ENTITY = "tbl_struktur_tupoksi"
const KAPRODI_JABATAN_DEFAULT = "Ketua Program Studi"

export class StrukturError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "StrukturError"
  }
}

const POSISI_ADMIN_INCLUDE = {
  dosen: { select: { id_dosen: true, nama: true, nidn: true, foto: true } },
  tupoksi: { orderBy: { urutan: "asc" } },
} satisfies Prisma.tbl_struktur_posisiInclude

type PosisiRow = Prisma.tbl_struktur_posisiGetPayload<{ include: typeof POSISI_ADMIN_INCLUDE }>

function resolveFoto(value: string | null): string | null {
  if (!value) return null
  if (/^https?:\/\//i.test(value)) return value
  return getPublicUrl("images", value) ?? value
}

function toStrukturPosisiAdmin(row: PosisiRow): StrukturPosisiAdmin {
  return {
    id: String(row.id_posisi),
    parentId: row.parent_id !== null ? String(row.parent_id) : null,
    jabatan: row.jabatan,
    nama: row.dosen ? null : row.nama,
    dosenId: row.dosen_id !== null ? String(row.dosen_id) : null,
    dosenNama: row.dosen?.nama ?? null,
    dosenNidn: row.dosen?.nidn ?? null,
    dosenFoto: row.dosen ? resolveFoto(row.dosen.foto) : null,
    urutan: row.urutan,
    jalur: row.jalur_sambung,
    isKaprodi: row.is_kaprodi,
    tupoksi: row.tupoksi.map((item) => ({
      id: String(item.id_tupoksi),
      isi: item.isi,
      urutan: item.urutan,
    })),
  }
}

/**
 * Kartu Kaprodi SELALU ditarik live dari dosen yang jabatan_struktural-nya
 * "Ketua Program Studi" -- bukan dari dosen_id yang tersimpan di baris posisi.
 * Kalau nggak ada dosen dengan jabatan itu, kartu tetap ada (sebagai root),
 * cuma fotonya kosong & ditandai "invalid" di sisi UI (posisi-node.tsx).
 */
async function resolveKaprodiDosen() {
  return prisma.tbl_dosen.findFirst({
    where: { jabatan_struktural: KAPRODI_JABATAN_DEFAULT },
    select: { id_dosen: true, nama: true, nidn: true, foto: true },
  })
}

function withLiveKaprodi(
  admin: StrukturPosisiAdmin,
  dosen: { id_dosen: bigint; nama: string; nidn: string; foto: string | null } | null,
): StrukturPosisiAdmin {
  return {
    ...admin,
    nama: null,
    dosenId: dosen ? String(dosen.id_dosen) : null,
    dosenNama: dosen?.nama ?? null,
    dosenNidn: dosen?.nidn ?? null,
    dosenFoto: dosen ? resolveFoto(dosen.foto) : null,
  }
}

async function ensureKaprodi() {
  const flagged = await prisma.tbl_struktur_posisi.findFirst({ where: { is_kaprodi: true } })
  if (flagged) return flagged

  return prisma.tbl_struktur_posisi.create({
    data: { jabatan: KAPRODI_JABATAN_DEFAULT, is_kaprodi: true, urutan: 0 },
  })
}

/** Dilempar di atas satu "kelompok sibling" (parent yang sama) -- max 1 kartu jalur "lurus". */
async function assertSingleLurus(parentId: bigint | null, excludeId?: bigint) {
  if (parentId === null) return
  const existing = await prisma.tbl_struktur_posisi.findFirst({
    where: {
      parent_id: parentId,
      jalur_sambung: "lurus",
      ...(excludeId !== undefined ? { NOT: { id_posisi: excludeId } } : {}),
    },
  })
  if (existing) {
    throw new StrukturError(
      `Level ini sudah punya posisi jalur lurus ("${existing.jabatan}"). Pilih menyamping, atau ubah yang lama dulu.`,
    )
  }
}

async function reindexSiblings(parentId: bigint) {
  const siblings = await prisma.tbl_struktur_posisi.findMany({
    where: { parent_id: parentId },
    orderBy: [{ urutan: "asc" }, { id_posisi: "asc" }],
    select: { id_posisi: true },
  })
  await Promise.all(
    siblings.map((item, index) =>
      prisma.tbl_struktur_posisi.update({ where: { id_posisi: item.id_posisi }, data: { urutan: index } }),
    ),
  )
}

/**
 * Pas posisi "lurus" di-promote, satu anaknya harus ambil alih jalur lurus (nerusin
 * garis utama), sisanya jadi kartu samping berselang-seling kiri/kanan. Kalau posisi
 * yang dihapus sendiri kartu samping, semua anaknya tetap di sisi yang sama (nggak
 * pernah ikut jadi bagian garis utama -- ini aturan final dari diskusi kita).
 */
function reassignPromotedJalur(
  children: { id_posisi: bigint }[],
  parentWasLurus: boolean,
  parentJalur: JalurSambung,
): Map<string, JalurSambung> {
  const map = new Map<string, JalurSambung>()
  if (!parentWasLurus) {
    for (const child of children) map.set(child.id_posisi.toString(), parentJalur)
    return map
  }
  children.forEach((child, index) => {
    map.set(child.id_posisi.toString(), index === 0 ? "lurus" : index % 2 === 1 ? "kiri" : "kanan")
  })
  return map
}

// ============================================================
// QUERY
// ============================================================

export async function getStrukturTreeAdmin(): Promise<StrukturPosisiAdmin[]> {
  await ensureKaprodi()

  const [rows, kaprodiDosen] = await Promise.all([
    prisma.tbl_struktur_posisi.findMany({
      include: POSISI_ADMIN_INCLUDE,
      orderBy: [{ parent_id: "asc" }, { urutan: "asc" }],
    }),
    resolveKaprodiDosen(),
  ])

  return rows.map((row) => {
    const admin = toStrukturPosisiAdmin(row)
    return row.is_kaprodi ? withLiveKaprodi(admin, kaprodiDosen) : admin
  })
}

// ============================================================
// MUTASI -- POSISI
// ============================================================

export async function createPosisi(
  input: StrukturPosisiCreateInput,
  actor: Actor,
): Promise<StrukturPosisiAdmin> {
  const referenceId = parseBigIntId(input.referenceId)

  const reference = await prisma.tbl_struktur_posisi.findUnique({ where: { id_posisi: referenceId } })
  if (!reference) throw new StrukturError("Node acuan tidak ditemukan.")

  const dosenId = input.dosenId ? parseBigIntId(input.dosenId) : null
  const dosenRelation = dosenId ? { connect: { id_dosen: dosenId } } : undefined

  if (input.arah === "atas") {
    // Menyisipkan level baru DI ATAS `reference` (lewat (+) di garis, atau (+) di kartu
    // Kaprodi kalau dia belum punya atasan). Node baru ambil alih slot (jalur) lama
    // reference, lalu reference sendiri jadi anak "lurus" dari node baru -- nerusin
    // garis lurus ke bawah persis seperti sebelumnya, cuma lewat satu level tambahan.
    const row = await prisma.$transaction(async (tx) => {
      const created = await tx.tbl_struktur_posisi.create({
        data: {
          jabatan: input.jabatan,
          nama: dosenId ? null : input.nama,
          dosen: dosenRelation,
          jalur_sambung: reference.jalur_sambung,
          parent: reference.parent_id !== null ? { connect: { id_posisi: reference.parent_id } } : undefined,
          urutan: reference.urutan,
        },
        include: POSISI_ADMIN_INCLUDE,
      })

      await tx.tbl_struktur_posisi.update({
        where: { id_posisi: reference.id_posisi },
        data: { parent_id: created.id_posisi, jalur_sambung: "lurus" },
      })

      return created
    })

    await logEntityMutation({
      actor,
      action: "create",
      entity: ENTITY,
      entityId: row.id_posisi,
      deskripsi: `${actor.nama} menambahkan posisi "${row.jabatan}" di atas "${reference.jabatan}".`,
      dataBaru: input,
    })

    return toStrukturPosisiAdmin(row)
  }

  let data: Prisma.tbl_struktur_posisiCreateInput

  if (input.arah === "bawah") {
    if (input.jalur === "lurus") await assertSingleLurus(reference.id_posisi)

    const siblingCount = await prisma.tbl_struktur_posisi.count({ where: { parent_id: reference.id_posisi } })
    data = {
      jabatan: input.jabatan,
      nama: dosenId ? null : input.nama,
      dosen: dosenRelation,
      jalur_sambung: input.jalur,
      parent: { connect: { id_posisi: reference.id_posisi } },
      urutan: siblingCount,
    }
  } else {
    // kiri / kanan -- selalu sejajar reference, jalur ikut tombolnya (bukan dialog).
    if (reference.parent_id === null) {
      throw new StrukturError("Posisi ini belum punya atasan, jadi belum bisa ditambah sejajar.")
    }

    const parentId = reference.parent_id
    const jalur: JalurSambung = input.arah === "kiri" ? "kiri" : "kanan"
    const urutan = input.arah === "kiri" ? reference.urutan : reference.urutan + 1

    await prisma.tbl_struktur_posisi.updateMany({
      where: { parent_id: parentId, urutan: { gte: urutan } },
      data: { urutan: { increment: 1 } },
    })

    data = {
      jabatan: input.jabatan,
      nama: dosenId ? null : input.nama,
      dosen: dosenRelation,
      jalur_sambung: jalur,
      parent: { connect: { id_posisi: parentId } },
      urutan,
    }
  }

  const row = await prisma.tbl_struktur_posisi.create({ data, include: POSISI_ADMIN_INCLUDE })

  await logEntityMutation({
    actor,
    action: "create",
    entity: ENTITY,
    entityId: row.id_posisi,
    deskripsi: `${actor.nama} menambahkan posisi "${row.jabatan}".`,
    dataBaru: input,
  })

  return toStrukturPosisiAdmin(row)
}

export async function updatePosisi(
  id: bigint,
  input: StrukturPosisiUpdateInput,
  actor: Actor,
): Promise<StrukturPosisiAdmin> {
  const before = await prisma.tbl_struktur_posisi.findUniqueOrThrow({ where: { id_posisi: id } })

  if (before.is_kaprodi) {
    // Jabatan & sumber dosen Kaprodi terkunci -- selalu live dari SDM (lihat getStrukturTreeAdmin).
    // Satu-satunya yang boleh diubah di sini adalah jalur, dan itu pun cuma relevan kalau
    // Kaprodi sudah punya atasan (mis. Dekan).
    if (before.parent_id !== null) {
      if (input.jalur === "lurus") await assertSingleLurus(before.parent_id, id)
      await prisma.tbl_struktur_posisi.update({ where: { id_posisi: id }, data: { jalur_sambung: input.jalur } })
    }

    const row = await prisma.tbl_struktur_posisi.findUniqueOrThrow({ where: { id_posisi: id }, include: POSISI_ADMIN_INCLUDE })
    const kaprodiDosen = await resolveKaprodiDosen()

    await logEntityMutation({
      actor,
      action: "update",
      entity: ENTITY,
      entityId: id,
      deskripsi: `${actor.nama} mengubah jalur posisi Ketua Program Studi.`,
      dataLama: before,
      dataBaru: input,
    })

    return withLiveKaprodi(toStrukturPosisiAdmin(row), kaprodiDosen)
  }

  if (input.jalur === "lurus") await assertSingleLurus(before.parent_id, id)

  const dosenId = input.dosenId ? parseBigIntId(input.dosenId) : null
  const row = await prisma.tbl_struktur_posisi.update({
    where: { id_posisi: id },
    data: {
      jabatan: input.jabatan,
      nama: dosenId ? null : input.nama,
      jalur_sambung: input.jalur,
      dosen: dosenId ? { connect: { id_dosen: dosenId } } : { disconnect: true },
    },
    include: POSISI_ADMIN_INCLUDE,
  })

  await logEntityMutation({
    actor,
    action: "update",
    entity: ENTITY,
    entityId: row.id_posisi,
    deskripsi: `${actor.nama} mengubah posisi "${row.jabatan}".`,
    dataLama: before,
    dataBaru: input,
  })

  return toStrukturPosisiAdmin(row)
}

export async function deletePosisi(id: bigint, mode: "cascade" | "promote", actor: Actor): Promise<void> {
  const before = await prisma.tbl_struktur_posisi.findUniqueOrThrow({ where: { id_posisi: id } })

  if (before.is_kaprodi) {
    throw new StrukturError("Posisi Ketua Program Studi tidak bisa dihapus.")
  }

  const all = await prisma.tbl_struktur_posisi.findMany({
    select: { id_posisi: true, parent_id: true, jalur_sambung: true, urutan: true, jabatan: true, is_kaprodi: true },
  })
  const kaprodi = all.find((item) => item.is_kaprodi)
  if (!kaprodi) throw new StrukturError("Data Kaprodi tidak ditemukan.")

  const ancestorIds = new Set<string>()
  {
    let current = kaprodi.parent_id
    while (current !== null) {
      ancestorIds.add(current.toString())
      current = all.find((item) => item.id_posisi === current)?.parent_id ?? null
    }
  }

  if (ancestorIds.has(id.toString())) {
    // `before` adalah bagian rantai di atas Kaprodi. Anak yang menuju Kaprodi WAJIB
    // di-bypass (otomatis, nggak peduli mode), cabang lain di bawah `before` (kalau ada)
    // ikut mode yang dipilih persis seperti hapus posisi biasa.
    const children = all.filter((item) => item.parent_id === id)
    const chainChild = children.find((item) => item.id_posisi === kaprodi.id_posisi || ancestorIds.has(item.id_posisi.toString()))
    const others = children.filter((item) => item.id_posisi !== chainChild?.id_posisi)

    if (others.length > 0 && mode === "promote" && before.parent_id === null) {
      throw new StrukturError('Tidak ada atasan untuk menampung turunan; pilih "hapus beserta turunan".')
    }

    await prisma.$transaction(async (tx) => {
      if (chainChild) {
        await tx.tbl_struktur_posisi.update({
          where: { id_posisi: chainChild.id_posisi },
          data: { parent_id: before.parent_id, jalur_sambung: "lurus" },
        })
      }

      if (mode === "promote") {
        for (const other of others) {
          await tx.tbl_struktur_posisi.update({ where: { id_posisi: other.id_posisi }, data: { parent_id: before.parent_id } })
        }
      }
      // mode "cascade": `others` (+ turunannya) otomatis ikut terhapus lewat ON DELETE
      // CASCADE begitu `before` dihapus, karena chainChild sudah di-bypass duluan di atas.

      await tx.tbl_struktur_posisi.delete({ where: { id_posisi: id } })
    })

    if (before.parent_id !== null) await reindexSiblings(before.parent_id)

    await logEntityMutation({
      actor,
      action: "delete",
      entity: ENTITY,
      entityId: id,
      deskripsi: `${actor.nama} menghapus posisi "${before.jabatan}" dari rantai di atas Kaprodi; posisi di bawahnya tersambung otomatis.`,
      dataLama: before,
    })
    return
  }

  // Posisi biasa (bukan rantai Kaprodi) -- cascade/promote seperti sebelumnya.
  const directChildren = all.filter((item) => item.parent_id === id)

  if (directChildren.length > 0 && mode === "promote" && before.parent_id === null) {
    throw new StrukturError('Tidak ada atasan untuk menampung turunan; pilih "hapus beserta turunan".')
  }

  await prisma.$transaction(async (tx) => {
    if (mode === "promote" && directChildren.length > 0) {
      const sorted = [...directChildren].sort((a, b) => a.urutan - b.urutan)
      const jalurMap = reassignPromotedJalur(sorted, before.jalur_sambung === "lurus", before.jalur_sambung)
      for (const child of sorted) {
        await tx.tbl_struktur_posisi.update({
          where: { id_posisi: child.id_posisi },
          data: { parent_id: before.parent_id, jalur_sambung: jalurMap.get(child.id_posisi.toString()) },
        })
      }
    }
    await tx.tbl_struktur_posisi.delete({ where: { id_posisi: id } })
  })

  if (before.parent_id !== null) await reindexSiblings(before.parent_id)

  await logEntityMutation({
    actor,
    action: "delete",
    entity: ENTITY,
    entityId: id,
    deskripsi:
      mode === "promote"
        ? `${actor.nama} menghapus posisi "${before.jabatan}" dan menaikkan posisi bawahannya satu tingkat.`
        : `${actor.nama} menghapus posisi "${before.jabatan}" beserta turunannya.`,
    dataLama: before,
  })
}

// ============================================================
// MUTASI -- TUPOKSI (tidak berubah dari versi sebelumnya)
// ============================================================

export async function createTupoksi(input: StrukturTupoksiInput, actor: Actor): Promise<StrukturTupoksiAdmin> {
  const posisiId = parseBigIntId(input.posisiId)

  const posisi = await prisma.tbl_struktur_posisi.findUnique({ where: { id_posisi: posisiId } })
  if (!posisi) throw new StrukturError("Posisi tidak ditemukan.")

  const count = await prisma.tbl_struktur_tupoksi.count({ where: { posisi_id: posisiId } })
  if (count >= STRUKTUR_TUPOKSI_MAX_ITEMS) {
    throw new StrukturError(`Tupoksi untuk satu posisi maksimal ${STRUKTUR_TUPOKSI_MAX_ITEMS} poin.`)
  }

  const row = await prisma.tbl_struktur_tupoksi.create({
    data: { posisi_id: posisiId, isi: input.isi, urutan: count },
  })

  await logEntityMutation({
    actor,
    action: "create",
    entity: TUPOKSI_ENTITY,
    entityId: row.id_tupoksi,
    deskripsi: `${actor.nama} menambahkan poin tupoksi pada "${posisi.jabatan}".`,
    dataBaru: input,
  })

  return { id: String(row.id_tupoksi), isi: row.isi, urutan: row.urutan }
}

export async function updateTupoksi(id: bigint, input: StrukturTupoksiUpdateInput, actor: Actor): Promise<StrukturTupoksiAdmin> {
  const before = await prisma.tbl_struktur_tupoksi.findUniqueOrThrow({ where: { id_tupoksi: id } })
  const row = await prisma.tbl_struktur_tupoksi.update({ where: { id_tupoksi: id }, data: { isi: input.isi } })

  await logEntityMutation({
    actor,
    action: "update",
    entity: TUPOKSI_ENTITY,
    entityId: row.id_tupoksi,
    deskripsi: `${actor.nama} mengubah poin tupoksi.`,
    dataLama: before,
    dataBaru: input,
  })

  return { id: String(row.id_tupoksi), isi: row.isi, urutan: row.urutan }
}

export async function deleteTupoksi(id: bigint, actor: Actor): Promise<void> {
  const before = await prisma.tbl_struktur_tupoksi.findUniqueOrThrow({ where: { id_tupoksi: id } })
  await prisma.tbl_struktur_tupoksi.delete({ where: { id_tupoksi: id } })

  await logEntityMutation({
    actor,
    action: "delete",
    entity: TUPOKSI_ENTITY,
    entityId: id,
    deskripsi: `${actor.nama} menghapus poin tupoksi.`,
    dataLama: before,
  })
}
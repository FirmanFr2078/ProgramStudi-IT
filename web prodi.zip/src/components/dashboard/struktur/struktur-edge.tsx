"use client"

import { EdgeLabelRenderer, getSmoothStepPath, type Edge, type EdgeProps } from "@xyflow/react"
import { PlusIcon } from "lucide-react"

export type StrukturEdgeData = {
  jalur: "lurus" | "kiri" | "kanan"
  warna: "hijau" | "biasa"
  showInsert: boolean
  onInsert: () => void
  /** "dashboard" = garis utama hijau; "landing" = garis utama putih. Satu komponen, beda warna saja. */
  variant?: "dashboard" | "landing"
}

type StrukturEdgeType = Edge<StrukturEdgeData>

const WARNA_CLASS: Record<"dashboard" | "landing", Record<"hijau" | "biasa", string>> = {
  dashboard: { hijau: "stroke-emerald-500", biasa: "stroke-border" },
  landing: { hijau: "stroke-white", biasa: "stroke-white/40" },
}

export function StrukturEdge({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  data,
}: EdgeProps<StrukturEdgeType>) {
  if (!data) return null

  let path: string
  let midX: number
  let midY: number

  if (data.jalur === "kiri" || data.jalur === "kanan") {
    const stubY = sourceY + 28
    path = `M${sourceX},${sourceY} L${sourceX},${stubY} L${targetX},${stubY} L${targetX},${targetY}`
    midX = sourceX
    midY = sourceY + 14
  } else {
    const [smoothPath, labelX, labelY] = getSmoothStepPath({
      sourceX,
      sourceY,
      sourcePosition,
      targetX,
      targetY,
      targetPosition,
      borderRadius: 0,
    })
    path = smoothPath
    midX = labelX
    midY = labelY
  }

  const variant = data.variant ?? "dashboard"

  return (
    <>
      <path
        id={id}
        className={`react-flow__edge-path ${WARNA_CLASS[variant][data.warna]}`}
        d={path}
        fill="none"
        strokeWidth={data.warna === "hijau" ? 2 : 1.5}
      />
      {data.showInsert && (
        <EdgeLabelRenderer>
          <button
            type="button"
            title="Sisipkan posisi di sini"
            aria-label="Sisipkan posisi di sini"
            onClick={(event) => {
              event.stopPropagation()
              data.onInsert()
            }}
            style={{ transform: `translate(-50%, -50%) translate(${midX}px, ${midY}px)` }}
            className={`nodrag nopan pointer-events-auto absolute flex size-6 items-center justify-center rounded-full border shadow-sm transition-opacity hover:opacity-100 ${
              data.warna === "hijau"
                ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-600 opacity-70"
                : "border-border bg-background text-muted-foreground opacity-50"
            }`}
          >
            <PlusIcon className="size-3.5" />
          </button>
        </EdgeLabelRenderer>
      )}
    </>
  )
}
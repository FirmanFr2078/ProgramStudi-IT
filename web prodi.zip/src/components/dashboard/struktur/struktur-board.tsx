"use client"

import { useMemo } from "react"
import { Panel, ReactFlow, ReactFlowProvider, useReactFlow, type Edge, type Node } from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { InfoIcon, Maximize2Icon, ZoomInIcon, ZoomOutIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { StrukturArah, StrukturPosisiAdmin } from "@/types"
import { useStrukturBoard } from "@/hooks/dashboard/struktur/use-struktur-board"
import { computeStrukturLayout } from "@/lib/struktur-layout"
import { PosisiDialog } from "./posisi-dialog"
import { PosisiNode, type PosisiNodeData } from "./posisi-node"
import { StrukturEdge, type StrukturEdgeData } from "./struktur-edge"
import { TupoksiSection } from "./tupoksi-section"

const nodeTypes = { posisi: PosisiNode }
const edgeTypes = { struktur: StrukturEdge }

function buildGraph(
  posisi: StrukturPosisiAdmin[],
  handlers: { onEdit: (id: string) => void; onArah: (id: string, arah: StrukturArah) => void },
) {
  const layout = computeStrukturLayout(posisi)
  const positionById = new Map(layout.nodes.map((item) => [item.id, item]))

  const childCountByParent = new Map<string, number>()
  for (const item of posisi) {
    if (item.parentId) childCountByParent.set(item.parentId, (childCountByParent.get(item.parentId) ?? 0) + 1)
  }

  const nodes: Node<PosisiNodeData>[] = posisi.map((item) => {
    const pos = positionById.get(item.id) ?? { x: 0, y: 0 }
    return {
      id: item.id,
      type: "posisi",
      position: { x: pos.x, y: pos.y },
      data: {
        posisi: item,
        hasChildren: (childCountByParent.get(item.id) ?? 0) > 0,
        onEdit: handlers.onEdit,
        onArah: handlers.onArah,
      },
      // Drag dicabut -- layout 100% dihitung dari struktur (lihat struktur-layout.ts).
      draggable: false,
    }
  })

  const edges: Edge<StrukturEdgeData>[] = layout.edges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
    type: "struktur",
    data: {
      jalur: edge.jalur,
      warna: edge.warna,
      showInsert: edge.showInsert,
      variant: "dashboard",
      onInsert: () => handlers.onArah(edge.target, "atas"),
    },
  }))

  return { nodes, edges }
}

function BoardInfo() {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger
          className="flex size-7 items-center justify-center rounded-full border bg-card text-muted-foreground shadow-sm transition-colors hover:text-primary"
          aria-label="Keterangan board"
        >
          <InfoIcon className="size-3.5" />
        </TooltipTrigger>
        <TooltipContent side="left" className="max-w-60 text-left">
          <div className="space-y-1">
            <p>
              <strong>+</strong> di tepi kartu : tambah posisi
            </p>
            <p>
              <strong className="text-emerald-600">+</strong> di garis hijau : sisipkan level baru
            </p>
            <p>klik kartu : ubah data posisi</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}

function BoardZoomControls() {
  const { zoomIn, zoomOut, fitView } = useReactFlow()
  const buttonClassName =
    "flex size-8 items-center justify-center rounded-lg border bg-card text-muted-foreground shadow-sm transition-colors hover:border-primary/50 hover:text-primary"

  return (
    <Panel position="bottom-left" className="flex gap-1.5">
      <button type="button" title="Perbesar" aria-label="Perbesar" onClick={() => zoomIn()} className={buttonClassName}>
        <ZoomInIcon className="size-4" />
      </button>
      <button type="button" title="Perkecil" aria-label="Perkecil" onClick={() => zoomOut()} className={buttonClassName}>
        <ZoomOutIcon className="size-4" />
      </button>
      {/* Layout selalu dihitung otomatis dari struktur, jadi tombol ini sekarang
          cuma soal zoom -- nggak perlu "merapikan" apa-apa lagi. */}
      <button
        type="button"
        title="Kembalikan tampilan"
        aria-label="Kembalikan tampilan"
        onClick={() => fitView({ padding: 0.4, maxZoom: 1 })}
        className={buttonClassName}
      >
        <Maximize2Icon className="size-4" />
      </button>
    </Panel>
  )
}

export function StrukturBoard({ initialData }: { initialData: StrukturPosisiAdmin[] }) {
  const board = useStrukturBoard(initialData)

  const { nodes, edges } = useMemo(
    () => buildGraph(board.posisi, { onEdit: board.openEditDialog, onArah: board.openCreateDialog }),
    [board.posisi, board.openEditDialog, board.openCreateDialog],
  )

  return (
    <div className="flex flex-col gap-3">
      {board.errorMessage && (
        <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {board.errorMessage}
        </p>
      )}

      <div className="bg-board-glow relative h-105 w-full overflow-hidden rounded-xl border bg-muted/10">
        <ReactFlowProvider>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            nodesDraggable={false}
            fitView
            fitViewOptions={{ padding: 0.4, maxZoom: 1 }}
            minZoom={0.4}
            maxZoom={1.5}
            proOptions={{ hideAttribution: true }}
          >
            <BoardZoomControls />

            <Panel position="top-right">
              <BoardInfo />
            </Panel>

            <Panel position="bottom-right" className="flex gap-2">
              {board.isDirty && (
                <Button type="button" variant="outline" size="sm" disabled={board.isSaving} onClick={board.discardDraft}>
                  Batal
                </Button>
              )}
              <Button type="button" size="sm" disabled={!board.isDirty || board.isSaving} onClick={board.commitDraft}>
                {board.isSaving ? "Menyimpan..." : "Simpan Struktur"}
              </Button>
            </Panel>
          </ReactFlow>
        </ReactFlowProvider>
      </div>

      <TupoksiSection
        posisi={board.posisi}
        onAdd={board.addTupoksi}
        onUpdate={board.updateTupoksiItem}
        onDelete={board.deleteTupoksiItem}
      />

      <PosisiDialog
        dialog={board.dialog}
        posisi={board.posisi}
        dosenOptions={board.dosenOptions}
        isSaving={board.isSaving}
        onClose={board.closeDialog}
        onSubmit={board.submitPosisi}
        onDeletePosisi={board.deletePosisiNode}
      />
    </div>
  )
}
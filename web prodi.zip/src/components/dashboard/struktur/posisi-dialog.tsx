"use client"

import { useState } from "react"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "cn"
import { KETUA_PROGRAM_STUDI } from "@/config/structural-roles"
import type { DialogState } from "@/hooks/dashboard/struktur/use-struktur-board"
import { getAncestorIdsOfKaprodi, getDescendantIds } from "@/lib/struktur-layout"
import type { DosenAdmin, JalurSambung, StrukturPosisiAdmin } from "@/types"

const ARAH_LABEL: Record<string, string> = { atas: "atas", bawah: "bawah", kiri: "kiri", kanan: "kanan" }

type FormValues = { sumber: "dosen" | "custom"; dosenId: string | null; nama: string; jabatan: string; jalur: JalurSambung }
const EMPTY: FormValues = { sumber: "custom", dosenId: null, nama: "", jabatan: "", jalur: "lurus" }

function toFormValues(posisi: StrukturPosisiAdmin | undefined): FormValues {
  if (!posisi) return EMPTY
  return {
    sumber: posisi.dosenId ? "dosen" : "custom",
    dosenId: posisi.dosenId,
    nama: posisi.nama ?? "",
    jabatan: posisi.jabatan,
    jalur: posisi.jalur,
  }
}

function countDescendants(all: StrukturPosisiAdmin[], id: string): number {
  return getDescendantIds(all, id).length
}

/** Kalau `editing` bagian rantai di atas Kaprodi, cuma cabang SELAIN yang menuju Kaprodi
 * yang perlu masuk dialog hapus -- anak yang menuju Kaprodi selalu dibypass otomatis
 * di server, nggak pernah ikut dihitung/dihapus. */
function computeAncestorContext(posisi: StrukturPosisiAdmin[], editing: StrukturPosisiAdmin) {
  const ancestorIds = getAncestorIdsOfKaprodi(posisi)
  if (!ancestorIds.has(editing.id)) return null

  const kaprodi = posisi.find((item) => item.isKaprodi)
  const children = posisi.filter((item) => item.parentId === editing.id)
  const chainChild = children.find((item) => item.id === kaprodi?.id || ancestorIds.has(item.id))
  const others = children.filter((item) => item.id !== chainChild?.id)
  return { others, canPromote: editing.parentId !== null || others.length === 0 }
}

function DeleteChoice({
  editing,
  posisi,
  ancestorContext,
  onConfirm,
  onCancel,
}: {
  editing: StrukturPosisiAdmin
  posisi: StrukturPosisiAdmin[]
  ancestorContext: ReturnType<typeof computeAncestorContext>
  onConfirm: (mode: "cascade" | "promote") => void
  onCancel: () => void
}) {
  const roots = ancestorContext ? ancestorContext.others : posisi.filter((item) => item.parentId === editing.id)
  const childCount = roots.length
  const descendantCount = roots.reduce((sum, root) => sum + 1 + countDescendants(posisi, root.id), 0)
  const canPromote = ancestorContext ? ancestorContext.canPromote : editing.parentId !== null

  const [mode, setMode] = useState<"cascade" | "promote">("cascade")

  if (descendantCount === 0) {
    return (
      <>
        <DialogHeader>
          <DialogTitle>Hapus posisi</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">Hapus &quot;{editing.jabatan}&quot;?</p>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={onCancel}>
            Batal
          </Button>
          <Button type="button" variant="destructive" onClick={() => onConfirm("cascade")}>
            Hapus
          </Button>
        </DialogFooter>
      </>
    )
  }

  const optionClass = (active: boolean, disabled: boolean) =>
    cn(
      "w-full rounded-lg border px-3 py-2.5 text-left transition-colors",
      disabled ? "cursor-not-allowed opacity-50" : active ? "border-primary bg-primary/5" : "hover:border-primary/40",
    )

  return (
    <>
      <DialogHeader>
        <DialogTitle>Hapus &quot;{editing.jabatan}&quot;?</DialogTitle>
      </DialogHeader>

      {ancestorContext && (
        <p className="text-xs text-muted-foreground">
          Posisi di bawahnya menuju Ketua Program Studi tetap aman &amp; tersambung otomatis ke atasan berikutnya. Pilihan di
          bawah ini cuma soal cabang lain di bawah posisi ini.
        </p>
      )}

      <div className="space-y-2">
        <button type="button" onClick={() => setMode("cascade")} className={optionClass(mode === "cascade", false)}>
          <p className="text-sm font-medium">Hapus beserta semua turunannya</p>
          <p className="text-xs text-muted-foreground">{descendantCount} posisi ikut terhapus.</p>
        </button>
        <button
          type="button"
          disabled={!canPromote}
          onClick={() => canPromote && setMode("promote")}
          className={optionClass(mode === "promote", !canPromote)}
        >
          <p className="text-sm font-medium">Naikkan turunannya satu tingkat</p>
          <p className="text-xs text-muted-foreground">
            {canPromote
              ? `${childCount} posisi langsung pindah jadi bawahan langsung atasannya.`
              : "Tidak tersedia -- posisi ini tidak punya atasan untuk menampung turunannya."}
          </p>
        </button>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Batal
        </Button>
        <Button type="button" variant="destructive" onClick={() => onConfirm(mode)}>
          Hapus
        </Button>
      </DialogFooter>
    </>
  )
}

function PosisiForm({
  dialog,
  editing,
  posisi,
  dosenOptions,
  isSaving,
  onSubmit,
  onDeletePosisi,
  onClose,
}: {
  dialog: Extract<DialogState, { mode: "create" | "edit" }>
  editing: StrukturPosisiAdmin | undefined
  posisi: StrukturPosisiAdmin[]
  dosenOptions: DosenAdmin[]
  isSaving: boolean
  onSubmit: (values: { jabatan: string; dosenId: string | null; nama: string | null; jalur: JalurSambung }) => void
  onDeletePosisi: (id: string, mode: "cascade" | "promote") => void
  onClose: () => void
}) {
  const isKaprodi = editing?.isKaprodi ?? false

  // Jalur cuma ditanya pas nambah bawahan pertama ("bawah") atau pas edit (kalau sudah
  // punya atasan). Arah "atas" & "kiri/kanan" nggak butuh dialog jalur -- server yang
  // nentuin/ngikutin tombolnya (lihat database/struktur.ts).
  const showJalur =
    dialog.mode === "create" ? dialog.arah === "bawah" : Boolean(editing && editing.parentId !== null)

  const [values, setValues] = useState<FormValues>(() => (dialog.mode === "edit" ? toFormValues(editing) : EMPTY))
  const [confirmingDelete, setConfirmingDelete] = useState(false)

  if (confirmingDelete && editing) {
    return (
      <DeleteChoice
        editing={editing}
        posisi={posisi}
        ancestorContext={computeAncestorContext(posisi, editing)}
        onCancel={() => setConfirmingDelete(false)}
        onConfirm={(mode) => {
          onDeletePosisi(editing.id, mode)
          onClose()
        }}
      />
    )
  }

  const title =
    dialog.mode === "create" ? `Tambah posisi (${ARAH_LABEL[dialog.arah]})` : `Ubah posisi${editing ? ` — ${editing.jabatan}` : ""}`

  const relevantParentId = dialog.mode === "create" ? (dialog.arah === "bawah" ? dialog.referenceId : null) : editing?.parentId ?? null
  const lurusConflict =
    showJalur &&
    values.jalur === "lurus" &&
    posisi.some((item) => item.parentId === relevantParentId && item.jalur === "lurus" && item.id !== editing?.id)

  function handleDeleteClick() {
    if (!editing) return
    const ancestorContext = computeAncestorContext(posisi, editing)
    if (ancestorContext && ancestorContext.others.length === 0) {
      // Rantai lurus di atas Kaprodi, nggak ada cabang lain -- langsung hapus, nggak
      // perlu konfirmasi cascade/promote karena nggak ada yang perlu dipilih.
      onDeletePosisi(editing.id, "cascade")
      onClose()
      return
    }
    setConfirmingDelete(true)
  }

  function handleSubmit() {
    onSubmit({
      jabatan: isKaprodi ? KETUA_PROGRAM_STUDI : values.jabatan.trim(),
      dosenId: isKaprodi ? null : values.sumber === "dosen" ? values.dosenId : null,
      nama: isKaprodi ? null : values.sumber === "custom" ? values.nama.trim() || null : null,
      jalur: values.jalur,
    })
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>{title}</DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        {isKaprodi ? (
          <div className="space-y-1.5 rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
            <p>Kartu ini otomatis mengikuti dosen yang ditandai &quot;Ketua Program Studi&quot; di halaman SDM &gt; Dosen.</p>
            {!editing?.dosenId && (
              <p className="font-medium text-destructive">
                Belum ada dosen dengan jabatan itu — kartu tampil &quot;Invalid data jabatan Kaprodi&quot; sampai ditandai di SDM.
              </p>
            )}
          </div>
        ) : (
          <>
            <div className="space-y-1.5">
              <Label>Sumber</Label>
              <Select
                value={values.sumber}
                onValueChange={(value) => value && setValues((prev) => ({ ...prev, sumber: value as "dosen" | "custom" }))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dosen">Ambil dari data dosen</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {values.sumber === "dosen" ? (
              <div className="space-y-1.5">
                <Label>Dosen</Label>
                <Select
                  value={values.dosenId ?? ""}
                  onValueChange={(value) => value && setValues((prev) => ({ ...prev, dosenId: value }))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Pilih dosen" />
                  </SelectTrigger>
                  <SelectContent>
                    {dosenOptions.map((dosen) => (
                      <SelectItem key={dosen.id} value={dosen.id}>
                        {dosen.nama} — {dosen.nidn}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="space-y-1.5">
                <Label htmlFor="posisi-nama">Nama (opsional)</Label>
                <Input
                  id="posisi-nama"
                  value={values.nama}
                  onChange={(event) => setValues((prev) => ({ ...prev, nama: event.target.value }))}
                  placeholder="Kosongkan kalau belum ada orangnya"
                />
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="posisi-jabatan">Jabatan</Label>
              <Input
                id="posisi-jabatan"
                value={values.jabatan}
                onChange={(event) => setValues((prev) => ({ ...prev, jabatan: event.target.value }))}
                placeholder='Misal: "Koordinator PKL"'
              />
            </div>
          </>
        )}

        {showJalur && (
          <div className="space-y-1.5">
            <Label>Jalur</Label>
            <Select
              value={values.jalur}
              onValueChange={(value) => value && setValues((prev) => ({ ...prev, jalur: value as JalurSambung }))}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lurus">Lurus (garis utama)</SelectItem>
                <SelectItem value="kiri">Menyamping kiri</SelectItem>
                <SelectItem value="kanan">Menyamping kanan</SelectItem>
              </SelectContent>
            </Select>
            {lurusConflict && (
              <p className="text-xs text-destructive">
                Level ini sudah punya posisi jalur lurus. Pilih menyamping, atau ubah yang lama dulu.
              </p>
            )}
          </div>
        )}
      </div>

      <DialogFooter className="justify-between sm:justify-between">
        {dialog.mode === "edit" && editing && !editing.isKaprodi ? (
          <Button type="button" variant="destructive" onClick={handleDeleteClick}>
            Hapus posisi
          </Button>
        ) : (
          <span />
        )}

        <Button
          type="button"
          disabled={
            isSaving ||
            lurusConflict ||
            (!isKaprodi && !values.jabatan.trim()) ||
            (!isKaprodi && values.sumber === "dosen" && !values.dosenId)
          }
          onClick={handleSubmit}
        >
          {isSaving ? "Menyimpan..." : "Simpan"}
        </Button>
      </DialogFooter>
    </>
  )
}

export function PosisiDialog({
  dialog,
  posisi,
  dosenOptions,
  isSaving,
  onClose,
  onSubmit,
  onDeletePosisi,
}: {
  dialog: DialogState
  posisi: StrukturPosisiAdmin[]
  dosenOptions: DosenAdmin[]
  isSaving: boolean
  onClose: () => void
  onSubmit: (values: { jabatan: string; dosenId: string | null; nama: string | null; jalur: JalurSambung }) => void
  onDeletePosisi: (id: string, mode: "cascade" | "promote") => void
}) {
  const editing = dialog.mode === "edit" ? posisi.find((item) => item.id === dialog.posisiId) : undefined
  const isOpen = dialog.mode !== "closed"

  const formKey =
    dialog.mode === "edit" ? `edit-${dialog.posisiId}` : dialog.mode === "create" ? `create-${dialog.referenceId}-${dialog.arah}` : "closed"

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        {dialog.mode !== "closed" && (
          <PosisiForm
            key={formKey}
            dialog={dialog}
            editing={editing}
            posisi={posisi}
            dosenOptions={dosenOptions}
            isSaving={isSaving}
            onSubmit={onSubmit}
            onDeletePosisi={onDeletePosisi}
            onClose={onClose}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}
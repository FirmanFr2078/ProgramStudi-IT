import type { JalurSambung, StrukturPosisiAdmin } from "@/types"

const CARD_WIDTH = 224 // samain sama w-56 di posisi-node.tsx
const GAP_X = 48
const LEVEL_HEIGHT = 150

export type StrukturLayoutNode = { id: string; x: number; y: number }
export type StrukturLayoutEdge = {
  id: string
  source: string
  target: string
  jalur: JalurSambung
  warna: "hijau" | "biasa"
  showInsert: boolean
}

export type StrukturLayout = { nodes: StrukturLayoutNode[]; edges: StrukturLayoutEdge[] }

/** Dipakai di layout engine (client) & deletePosisi (server) -- jalan dari Kaprodi naik ke atas. */
export function getAncestorIdsOfKaprodi(list: { id: string; parentId: string | null; isKaprodi: boolean }[]): Set<string> {
  const kaprodi = list.find((item) => item.isKaprodi)
  const result = new Set<string>()
  let current = kaprodi?.parentId ?? null
  while (current) {
    result.add(current)
    current = list.find((item) => item.id === current)?.parentId ?? null
  }
  return result
}

export function getDescendantIds(list: { id: string; parentId: string | null }[], rootId: string): string[] {
  const ids: string[] = []
  let frontier = [rootId]
  while (frontier.length > 0) {
    const children = list.filter((item) => item.parentId !== null && frontier.includes(item.parentId)).map((item) => item.id)
    ids.push(...children)
    frontier = children
  }
  return ids
}

/**
 * Menghitung posisi (x, y) tiap kartu murni dari struktur: baris = level (BFS depth),
 * kolom = lebar subtree tiap anak dijejer kiri-ke-kanan sesuai `urutan`. Nggak ada drag
 * manual lagi -- hasilnya selalu rapi & deterministik dari data, sama seperti alasan
 * kenapa tombol "Kembalikan tampilan" sekarang cukup zoom-to-fit.
 */
export function computeStrukturLayout(posisi: StrukturPosisiAdmin[]): StrukturLayout {
  const byParent = new Map<string | null, StrukturPosisiAdmin[]>()
  for (const item of posisi) {
    const list = byParent.get(item.parentId) ?? []
    list.push(item)
    byParent.set(item.parentId, list)
  }
  for (const list of byParent.values()) list.sort((a, b) => a.urutan - b.urutan)

  const root = posisi.find((item) => item.parentId === null)

  const widthCache = new Map<string, number>()
  function subtreeWidth(id: string): number {
    const cached = widthCache.get(id)
    if (cached !== undefined) return cached
    const children = byParent.get(id) ?? []
    const width = children.length === 0 ? 1 : children.reduce((sum, child) => sum + subtreeWidth(child.id), 0)
    widthCache.set(id, width)
    return width
  }
  if (root) subtreeWidth(root.id)

  const positions = new Map<string, { x: number; y: number }>()
  function place(id: string, leftSlot: number, depth: number) {
    const children = byParent.get(id) ?? []
    const width = subtreeWidth(id)
    const centerSlot = leftSlot + width / 2
    positions.set(id, { x: centerSlot * (CARD_WIDTH + GAP_X), y: depth * LEVEL_HEIGHT })

    let cursor = leftSlot
    for (const child of children) {
      place(child.id, cursor, depth + 1)
      cursor += subtreeWidth(child.id)
    }
  }
  if (root) place(root.id, 0, 0)

  const nodes: StrukturLayoutNode[] = posisi.map((item) => {
    const pos = positions.get(item.id) ?? { x: 0, y: 0 }
    return { id: item.id, x: pos.x, y: pos.y }
  })

  // Rantai hijau ("garis utama"): Kaprodi, lalu turun lewat anak ber-jalur "lurus"
  // berturut-turut sampai mentok (node yang nggak punya anak "lurus" lagi).
  const kaprodi = posisi.find((item) => item.isKaprodi)
  const spineIds = new Set<string>()
  let spineTerminalId: string | null = null

  if (kaprodi) {
    let current: StrukturPosisiAdmin | undefined = kaprodi
    spineIds.add(current.id)
    while (current) {
      const children: StrukturPosisiAdmin[] = byParent.get(current.id) ?? []
      const lurusChild: StrukturPosisiAdmin | undefined = children.find((child) => child.jalur === "lurus")
      if (lurusChild) {
        spineIds.add(lurusChild.id)
        current = lurusChild
      } else {
        spineTerminalId = current.id
        current = undefined
      }
    }
  }

  const edges: StrukturLayoutEdge[] = posisi
    .filter((item) => item.parentId !== null)
    .map((item) => {
      const parentId = item.parentId as string
      const isLurusEdge = item.jalur === "lurus"
      let warna: "hijau" | "biasa" = "biasa"

      if (spineIds.has(parentId)) {
        if (isLurusEdge) warna = "hijau" // nerusin garis utama ke level berikutnya
        else if (parentId === spineTerminalId) warna = "hijau" // percabangan terakhir di ujung garis utama
      }

      return {
        id: `${parentId}-${item.id}`,
        source: parentId,
        target: item.id,
        jalur: item.jalur,
        warna,
        // (+) di garis cuma ada di garis vertikal "lurus" (termasuk rantai di atas Kaprodi) --
        // garis menyamping (kiri/kanan) nggak pernah punya (+), biar nggak bercampur sama (+) di kartu.
        showInsert: isLurusEdge,
      }
    })

  return { nodes, edges }
}
import { z } from "zod"

export const STRUKTUR_ARAH = ["atas", "bawah", "kiri", "kanan"] as const
export type StrukturArah = (typeof STRUKTUR_ARAH)[number]

export const JALUR_SAMBUNG = ["lurus", "kiri", "kanan"] as const
export type JalurSambung = (typeof JALUR_SAMBUNG)[number]

export const STRUKTUR_TUPOKSI_MAX_ITEMS = 20

const requiredText = (max: number, label: string) =>
  z.string().trim().min(1, `${label} wajib diisi`).max(max, `${label} maksimal ${max} karakter`)

const optionalText = (max: number, label: string) =>
  z
    .string()
    .trim()
    .max(max, `${label} maksimal ${max} karakter`)
    .nullable()
    .optional()
    .transform((value) => (value ? value : null))

const optionalIdRef = z
  .string()
  .trim()
  .min(1)
  .nullable()
  .optional()
  .transform((value) => (value ? value : null))

// Default "lurus" -- cuma relevan beneran pas arah === "bawah" (lihat database/struktur.ts).
// Utk arah lain, server yang nentuin jalur sebenarnya (bypass/ikut sisi tombol), jadi field
// ini aman dikirim apa adanya dari client tanpa perlu UI jalur ditampilkan.
const jalurSchema = z.enum(JALUR_SAMBUNG).optional().default("lurus")

// ============================================================
// POSISI
// ============================================================

export const strukturPosisiCreateSchema = z.object({
  referenceId: z.string().trim().min(1, "Node acuan wajib diisi"),
  arah: z.enum(STRUKTUR_ARAH, { message: "Arah tidak valid" }),
  jabatan: requiredText(100, "Jabatan"),
  dosenId: optionalIdRef,
  nama: optionalText(150, "Nama"),
  jalur: jalurSchema,
})
export type StrukturPosisiCreateInput = z.infer<typeof strukturPosisiCreateSchema>

export const strukturPosisiUpdateSchema = z.object({
  jabatan: requiredText(100, "Jabatan"),
  dosenId: optionalIdRef,
  nama: optionalText(150, "Nama"),
  jalur: jalurSchema,
})
export type StrukturPosisiUpdateInput = z.infer<typeof strukturPosisiUpdateSchema>

export const strukturPosisiDeleteSchema = z.object({
  mode: z.enum(["cascade", "promote"]).optional().default("cascade"),
})
export type StrukturPosisiDeleteInput = z.infer<typeof strukturPosisiDeleteSchema>

export type StrukturTupoksiAdmin = {
  id: string
  isi: string
  urutan: number
}

export type StrukturPosisiAdmin = {
  id: string
  parentId: string | null
  jabatan: string
  nama: string | null
  dosenId: string | null
  dosenNama: string | null
  dosenNidn: string | null
  dosenFoto: string | null
  urutan: number
  jalur: JalurSambung
  isKaprodi: boolean
  tupoksi: StrukturTupoksiAdmin[]
}

// ============================================================
// TUPOKSI
// ============================================================

export const strukturTupoksiInputSchema = z.object({
  posisiId: z.string().trim().min(1, "Posisi wajib diisi"),
  isi: requiredText(300, "Isi tupoksi"),
})
export type StrukturTupoksiInput = z.infer<typeof strukturTupoksiInputSchema>

export const strukturTupoksiUpdateSchema = z.object({
  isi: requiredText(300, "Isi tupoksi"),
})
export type StrukturTupoksiUpdateInput = z.infer<typeof strukturTupoksiUpdateSchema>
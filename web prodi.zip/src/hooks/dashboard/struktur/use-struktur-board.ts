"use client"

import { useEffect, useState } from "react"

import { getAncestorIdsOfKaprodi, getDescendantIds } from "@/lib/struktur-layout"
import type { DosenAdmin, JalurSambung, StrukturArah, StrukturPosisiAdmin } from "@/types"

const POSISI_URL = "/api/dashboard/struktur/posisi"
const TUPOKSI_URL = "/api/dashboard/struktur/tupoksi"
const DOSEN_URL = "/api/dashboard/sdm/dosen"

type ApiResponse<T> = {
  success: boolean
  data?: T
  message?: string
  errors?: Record<string, string[] | undefined>
}

export type DialogState =
  | { mode: "closed" }
  | { mode: "create"; referenceId: string; arah: StrukturArah }
  | { mode: "edit"; posisiId: string }

type PosisiFormValues = { jabatan: string; dosenId: string | null; nama: string | null; jalur: JalurSambung }

type PendingAction =
  | ({ kind: "create"; tempId: string; referenceId: string; arah: StrukturArah } & PosisiFormValues)
  | ({ kind: "update"; id: string } & PosisiFormValues)
  | { kind: "delete"; id: string; deleteMode: "cascade" | "promote" }
  | { kind: "tupoksi-create"; tempId: string; posisiId: string; isi: string }
  | { kind: "tupoksi-update"; id: string; isi: string }
  | { kind: "tupoksi-delete"; id: string }

type BoardState = { draft: StrukturPosisiAdmin[]; actions: PendingAction[] }

let tempCounter = 0
function createTempId(prefix: string) {
  tempCounter += 1
  return `${prefix}-${Date.now()}-${tempCounter}`
}

async function parseResponse<T>(response: Response): Promise<ApiResponse<T>> {
  return (await response.json()) as ApiResponse<T>
}

function resolveDosenFields(dosenId: string | null, dosenOptions: DosenAdmin[]) {
  if (!dosenId) return { dosenId: null, dosenNama: null, dosenNidn: null, dosenFoto: null }
  const dosen = dosenOptions.find((item) => item.id === dosenId)
  return { dosenId, dosenNama: dosen?.nama ?? null, dosenNidn: dosen?.nidn ?? null, dosenFoto: dosen?.foto ?? null }
}

/** Rapetin urutan sibling (tutup lubang bekas yang kehapus/kepromote). Posisi x/y nggak
 * perlu dihitung di sini lagi -- itu kerjaan struktur-layout.ts pas render. */
function compactSiblingsLocal(list: StrukturPosisiAdmin[], parentId: string | null): StrukturPosisiAdmin[] {
  const siblings = list.filter((item) => item.parentId === parentId).sort((a, b) => a.urutan - b.urutan)
  if (siblings.length === 0) return list
  const updates = new Map(siblings.map((item, index) => [item.id, index]))
  return list.map((item) => (updates.has(item.id) ? { ...item, urutan: updates.get(item.id)! } : item))
}

function reassignPromotedJalurLocal(
  children: StrukturPosisiAdmin[],
  parentWasLurus: boolean,
  parentJalur: JalurSambung,
): Map<string, JalurSambung> {
  const sorted = [...children].sort((a, b) => a.urutan - b.urutan)
  const map = new Map<string, JalurSambung>()
  if (!parentWasLurus) {
    sorted.forEach((child) => map.set(child.id, parentJalur))
    return map
  }
  sorted.forEach((child, index) => map.set(child.id, index === 0 ? "lurus" : index % 2 === 1 ? "kiri" : "kanan"))
  return map
}

function applyCreateLocal(
  list: StrukturPosisiAdmin[],
  dosenOptions: DosenAdmin[],
  action: Extract<PendingAction, { kind: "create" }>,
): StrukturPosisiAdmin[] {
  const reference = list.find((item) => item.id === action.referenceId)
  if (!reference) return list

  const base = {
    id: action.tempId,
    jabatan: action.jabatan,
    nama: action.dosenId ? null : action.nama,
    ...resolveDosenFields(action.dosenId, dosenOptions),
    isKaprodi: false,
    tupoksi: [],
  }

  if (action.arah === "bawah") {
    const siblingCount = list.filter((item) => item.parentId === reference.id).length
    return [...list, { ...base, jalur: action.jalur, parentId: reference.id, urutan: siblingCount }]
  }

  if (action.arah === "atas") {
    const shifted = list.map((item) =>
      item.id === reference.id ? { ...item, parentId: action.tempId, jalur: "lurus" as const } : item,
    )
    return [
      ...shifted,
      { ...base, jalur: reference.jalur, parentId: reference.parentId, urutan: reference.urutan },
    ]
  }

  if (reference.parentId === null) return list

  const jalur: JalurSambung = action.arah === "kiri" ? "kiri" : "kanan"
  const urutan = action.arah === "kiri" ? reference.urutan : reference.urutan + 1
  const shifted = list.map((item) =>
    item.parentId === reference.parentId && item.urutan >= urutan ? { ...item, urutan: item.urutan + 1 } : item,
  )
  return [...shifted, { ...base, jalur, parentId: reference.parentId, urutan }]
}

function applyDeleteLocal(list: StrukturPosisiAdmin[], id: string, mode: "cascade" | "promote"): StrukturPosisiAdmin[] {
  const target = list.find((item) => item.id === id)
  if (!target || target.isKaprodi) return list

  const ancestorIds = getAncestorIdsOfKaprodi(list)
  const kaprodi = list.find((item) => item.isKaprodi)

  if (ancestorIds.has(id)) {
    const children = list.filter((item) => item.parentId === id)
    const chainChild = children.find((item) => item.id === kaprodi?.id || ancestorIds.has(item.id))
    const others = children.filter((item) => item.id !== chainChild?.id)

    let next = list.filter((item) => item.id !== id)
    if (chainChild) {
      next = next.map((item) =>
        item.id === chainChild.id ? { ...item, parentId: target.parentId, jalur: "lurus" as const } : item,
      )
    }
    if (mode === "promote") {
      const otherIds = new Set(others.map((item) => item.id))
      next = next.map((item) => (otherIds.has(item.id) ? { ...item, parentId: target.parentId } : item))
    } else {
      const removeIds = new Set(others.flatMap((item) => [item.id, ...getDescendantIds(next, item.id)]))
      next = next.filter((item) => !removeIds.has(item.id))
    }
    return compactSiblingsLocal(next, target.parentId)
  }

  if (mode === "promote") {
    const directChildren = list.filter((item) => item.parentId === id)
    const jalurMap = reassignPromotedJalurLocal(directChildren, target.jalur === "lurus", target.jalur)
    const promoted = list
      .filter((item) => item.id !== id)
      .map((item) =>
        item.parentId === id ? { ...item, parentId: target.parentId, jalur: jalurMap.get(item.id) ?? item.jalur } : item,
      )
    return compactSiblingsLocal(promoted, target.parentId)
  }

  const toRemove = new Set([id, ...getDescendantIds(list, id)])
  return compactSiblingsLocal(
    list.filter((item) => !toRemove.has(item.id)),
    target.parentId,
  )
}

/** Buang create + aksi turunannya kalau kartu yang sama dibuat lalu dihapus lagi dalam draft yang sama. */
function compactActions(actions: PendingAction[]): PendingAction[] {
  const dropped = new Set<string>()
  let changed = true
  while (changed) {
    changed = false
    for (const action of actions) {
      if (action.kind === "delete" && !dropped.has(action.id)) {
        const createdThisDraft = actions.some((item) => item.kind === "create" && item.tempId === action.id)
        if (createdThisDraft) {
          dropped.add(action.id)
          changed = true
        }
      }
      if (action.kind === "create" && dropped.has(action.referenceId) && !dropped.has(action.tempId)) {
        dropped.add(action.tempId)
        changed = true
      }
    }
  }

  return actions.filter((action) => {
    if (action.kind === "create") return !dropped.has(action.tempId)
    if (action.kind === "tupoksi-create") return !dropped.has(action.posisiId)
    if ("id" in action) return !dropped.has(action.id)
    return true
  })
}

export function useStrukturBoard(initialData: StrukturPosisiAdmin[]) {
  const [savedPosisi, setSavedPosisi] = useState<StrukturPosisiAdmin[]>(initialData)
  const [state, setState] = useState<BoardState>({ draft: initialData, actions: [] })
  const [dosenOptions, setDosenOptions] = useState<DosenAdmin[]>([])
  const [dialog, setDialog] = useState<DialogState>({ mode: "closed" })
  const [isSaving, setIsSaving] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    fetch(DOSEN_URL, { credentials: "include" })
      .then((response) => parseResponse<DosenAdmin[]>(response))
      .then((result) => {
        if (result.success && result.data) setDosenOptions(result.data)
      })
      .catch(() => {})
  }, [])

  const isDirty = state.actions.length > 0

  function openCreateDialog(referenceId: string, arah: StrukturArah) {
    setErrorMessage(null)
    setDialog({ mode: "create", referenceId, arah })
  }

  function openEditDialog(posisiId: string) {
    setErrorMessage(null)
    setDialog({ mode: "edit", posisiId })
  }

  function closeDialog() {
    setDialog({ mode: "closed" })
  }

  function submitPosisi(values: PosisiFormValues) {
    if (dialog.mode === "closed") return

    if (dialog.mode === "create") {
      const tempId = createTempId("posisi")
      const action: PendingAction = { kind: "create", tempId, referenceId: dialog.referenceId, arah: dialog.arah, ...values }
      setState((prev) => ({ draft: applyCreateLocal(prev.draft, dosenOptions, action), actions: [...prev.actions, action] }))
    } else {
      const posisiId = dialog.posisiId
      setState((prev) => ({
        draft: prev.draft.map((item) =>
          item.id === posisiId
            ? {
                ...item,
                jabatan: values.jabatan,
                nama: values.dosenId ? null : values.nama,
                jalur: values.jalur,
                ...resolveDosenFields(values.dosenId, dosenOptions),
              }
            : item,
        ),
        actions: [...prev.actions, { kind: "update", id: posisiId, ...values }],
      }))
    }
    closeDialog()
  }

  function deletePosisiNode(id: string, deleteMode: "cascade" | "promote") {
    setState((prev) => {
      const removedIds =
        deleteMode === "cascade" && !getAncestorIdsOfKaprodi(prev.draft).has(id)
          ? new Set([id, ...getDescendantIds(prev.draft, id)])
          : new Set([id])
      const survivors = prev.actions.filter((action) => {
        if (action.kind === "delete") return true
        if (action.kind === "create") return !removedIds.has(action.tempId)
        if (action.kind === "tupoksi-create") return !removedIds.has(action.posisiId)
        if ("id" in action) return !removedIds.has(action.id)
        return true
      })
      return { draft: applyDeleteLocal(prev.draft, id, deleteMode), actions: [...survivors, { kind: "delete", id, deleteMode }] }
    })
  }

  function addTupoksi(posisiId: string, isi: string) {
    const tempId = createTempId("tupoksi")
    setState((prev) => ({
      draft: prev.draft.map((item) =>
        item.id === posisiId ? { ...item, tupoksi: [...item.tupoksi, { id: tempId, isi, urutan: item.tupoksi.length }] } : item,
      ),
      actions: [...prev.actions, { kind: "tupoksi-create", tempId, posisiId, isi }],
    }))
  }

  function updateTupoksiItem(id: string, isi: string) {
    setState((prev) => ({
      draft: prev.draft.map((item) => ({ ...item, tupoksi: item.tupoksi.map((t) => (t.id === id ? { ...t, isi } : t)) })),
      actions: [...prev.actions, { kind: "tupoksi-update", id, isi }],
    }))
  }

  function deleteTupoksiItem(id: string) {
    setState((prev) => ({
      draft: prev.draft.map((item) => ({ ...item, tupoksi: item.tupoksi.filter((t) => t.id !== id) })),
      actions: [...prev.actions, { kind: "tupoksi-delete", id }],
    }))
  }

  function discardDraft() {
    setState({ draft: savedPosisi, actions: [] })
    setErrorMessage(null)
  }

  async function commitDraft() {
    setIsSaving(true)
    setErrorMessage(null)

    const actions = compactActions(state.actions)
    const idMap = new Map<string, string>()
    const resolve = (id: string) => idMap.get(id) ?? id

    try {
      for (const action of actions) {
        if (action.kind === "create") {
          const response = await fetch(POSISI_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({
              referenceId: resolve(action.referenceId),
              arah: action.arah,
              jabatan: action.jabatan,
              dosenId: action.dosenId,
              nama: action.nama,
              jalur: action.jalur,
            }),
          })
          const result = await parseResponse<StrukturPosisiAdmin>(response)
          if (!result.success || !result.data) throw new Error(result.message ?? "Gagal menyimpan posisi baru.")
          idMap.set(action.tempId, result.data.id)
        } else if (action.kind === "update") {
          const response = await fetch(`${POSISI_URL}/${resolve(action.id)}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ jabatan: action.jabatan, dosenId: action.dosenId, nama: action.nama, jalur: action.jalur }),
          })
          const result = await parseResponse<unknown>(response)
          if (!result.success) throw new Error(result.message ?? "Gagal menyimpan perubahan posisi.")
        } else if (action.kind === "delete") {
          const response = await fetch(`${POSISI_URL}/${resolve(action.id)}`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ mode: action.deleteMode }),
          })
          const result = await parseResponse<unknown>(response)
          if (!result.success) throw new Error(result.message ?? "Gagal menghapus posisi.")
        } else if (action.kind === "tupoksi-create") {
          const response = await fetch(TUPOKSI_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ posisiId: resolve(action.posisiId), isi: action.isi }),
          })
          const result = await parseResponse<{ id: string }>(response)
          if (!result.success) throw new Error(result.message ?? "Gagal menyimpan tupoksi.")
          if (result.data) idMap.set(action.tempId, result.data.id)
        } else if (action.kind === "tupoksi-update") {
          await fetch(`${TUPOKSI_URL}/${resolve(action.id)}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify({ isi: action.isi }),
          })
        } else {
          await fetch(`${TUPOKSI_URL}/${resolve(action.id)}`, { method: "DELETE", credentials: "include" })
        }
      }

      const response = await fetch(POSISI_URL, { credentials: "include" })
      const result = await parseResponse<StrukturPosisiAdmin[]>(response)
      if (result.success && result.data) {
        setSavedPosisi(result.data)
        setState({ draft: result.data, actions: [] })
      } else {
        setState((prev) => ({ draft: prev.draft, actions: [] }))
      }
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Gagal menyimpan struktur. Coba lagi.")
    } finally {
      setIsSaving(false)
    }
  }

  return {
    posisi: state.draft,
    dosenOptions,
    dialog,
    isSaving,
    isDirty,
    errorMessage,
    openCreateDialog,
    openEditDialog,
    closeDialog,
    submitPosisi,
    deletePosisiNode,
    addTupoksi,
    updateTupoksiItem,
    deleteTupoksiItem,
    commitDraft,
    discardDraft,
  }
}